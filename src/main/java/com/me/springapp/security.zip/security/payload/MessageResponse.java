package com.me.springapp.security.payload;

public record MessageResponse(String message) {
}